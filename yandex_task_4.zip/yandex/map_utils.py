from geopy.distance import geodesic


def get_map_scale(toponym):
    envelope = toponym["boundedBy"]["Envelope"]
    left, bottom = envelope["lowerCorner"].split(" ")
    right, top = envelope["upperCorner"].split(" ")

    width = abs(float(right) - float(left))
    height = abs(float(top) - float(bottom))

    return f"{width},{height}"


def calculate_distance(point1, point2):
    return round(geodesic(point1, point2).meters)


def get_bounds(points):
    lons = [float(p[0]) for p in points]
    lats = [float(p[1]) for p in points]

    min_lon, max_lon = min(lons), max(lons)
    min_lat, max_lat = min(lats), max(lats)

    width = max_lon - min_lon
    height = max_lat - min_lat

    width += width * 0.2
    height += height * 0.2

    center_lon = (min_lon + max_lon) / 2
    center_lat = (min_lat + max_lat) / 2

    return {
        "ll": f"{center_lon},{center_lat}",
        "spn": f"{width},{height}"
    }


def get_point_color(hours_info):
    if not hours_info:
        return "gray"

    hours_text = hours_info.get("text", "").lower()
    if "круглосуточно" in hours_text:
        return "green"
    else:
        return "blue"
