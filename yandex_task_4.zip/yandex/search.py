import sys
from io import BytesIO
import requests
from PIL import Image
from map_utils import calculate_distance, get_bounds, get_point_color


def geocode_address(address):
    geocoder_api_server = "http://geocode-maps.yandex.ru/1.x/"

    geocoder_params = {
        "apikey": "8013b162-6b42-4997-9691-77b7074026e0",
        "geocode": address,
        "format": "json"
    }

    response = requests.get(geocoder_api_server, params=geocoder_params)
    if not response:
        raise Exception("Ошибка выполнения запроса к геокодеру")

    json_response = response.json()
    toponym = json_response["response"]["GeoObjectCollection"]["featureMember"][0]["GeoObject"]
    toponym_coords = toponym["Point"]["pos"].split(" ")
    toponym_address = toponym["metaDataProperty"]["GeocoderMetaData"]["text"]

    return {
        "coordinates": toponym_coords,
        "address": toponym_address
    }


def find_pharmacies(point_coords, count=10):
    search_api_server = "https://search-maps.yandex.ru/v1/"
    api_key = "dda3ddba-c9ea-4ead-9010-f43fbc15c6e3"

    search_params = {
        "apikey": api_key,
        "text": "аптека",
        "lang": "ru_RU",
        "ll": ",".join(point_coords),
        "type": "biz",
        "results": count
    }

    response = requests.get(search_api_server, params=search_params)
    if not response:
        raise Exception("Ошибка выполнения запроса к API поиска")

    json_response = response.json()
    if not json_response["features"]:
        raise Exception("Аптеки не найдены")

    pharmacies = []
    for org in json_response["features"]:
        org_coords = org["geometry"]["coordinates"]
        props = org["properties"]["CompanyMetaData"]

        pharmacies.append({
            "coordinates": [str(org_coords[0]), str(org_coords[1])],
            "name": props.get("name", "Название не указано"),
            "address": props.get("address", "Адрес не указан"),
            "hours": props.get("Hours", {}),
            "color": get_point_color(props.get("Hours", {}))
        })

    return pharmacies


def show_map(start_point, pharmacies):
    points = [
        f"{start_point['coordinates'][0]},{start_point['coordinates'][1]},pm2rdl"
    ]

    for pharmacy in pharmacies:
        points.append(
            f"{pharmacy['coordinates'][0]},{pharmacy['coordinates'][1]},"
            f"pm2{pharmacy['color']}l"
        )

    map_params = {
        "l": "map",
        "pt": "~".join(points),
        "apikey": "f3a0fe3a-b07e-4840-a1da-06f18b2ddf13"
    }

    all_coords = [start_point["coordinates"]] + [p["coordinates"] for p in pharmacies]
    bounds = get_bounds(all_coords)
    map_params.update(bounds)

    map_api_server = "https://static-maps.yandex.ru/1.x/"
    response = requests.get(map_api_server, params=map_params)

    Image.open(BytesIO(response.content)).show()


def print_pharmacies_info(start_point, pharmacies):
    print("\n" + "=" * 50)
    print(f"Исходный адрес: {start_point['address']}")
    print("\nНайденные аптеки:")

    for i, pharmacy in enumerate(pharmacies, 1):
        distance = calculate_distance(start_point["coordinates"], pharmacy["coordinates"])
        print(f"\n{i}. {pharmacy['name']}")
        print(f"   Адрес: {pharmacy['address']}")
        print(f"   Время работы: {pharmacy['hours'].get('text', 'нет данных')}")
        print(f"   Расстояние: {distance} метров")
        print(
            f"   Тип: {'круглосуточная' if pharmacy['color'] == 'green' else 'некруглосуточная' if pharmacy['color'] == 'blue' else 'нет данных'}")

    print("=" * 50 + "\n")


def main():
    if len(sys.argv) < 2:
        print("Использование: python pharmacy_search_10.py <адрес>")
        return

    try:
        address = " ".join(sys.argv[1:])

        start_point = geocode_address(address)

        pharmacies = find_pharmacies(start_point["coordinates"], count=10)

        print_pharmacies_info(start_point, pharmacies)

        show_map(start_point, pharmacies)

    except Exception as e:
        print(f"Ошибка: {e}")


if __name__ == "__main__":
    main()
