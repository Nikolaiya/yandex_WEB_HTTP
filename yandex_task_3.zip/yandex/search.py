import sys
from io import BytesIO
import requests
from PIL import Image
from map_utils import calculate_distance, get_bounds


def geocode_address(address):
    geocoder_api_server = "http://geocode-maps.yandex.ru/1.x/"

    geocoder_params = {
        "apikey": "8013b162-6b42-4997-9691-77b7074026e0",
        "geocode": address,
        "format": "json"
    }

    response = requests.get(geocoder_api_server, params=geocoder_params)
    if not response:
        raise Exception("Ошибка выполнения запроса к геокодеру")

    json_response = response.json()
    toponym = json_response["response"]["GeoObjectCollection"]["featureMember"][0]["GeoObject"]
    toponym_coords = toponym["Point"]["pos"].split(" ")
    toponym_address = toponym["metaDataProperty"]["GeocoderMetaData"]["text"]

    return {
        "coordinates": toponym_coords,
        "address": toponym_address
    }


def find_nearest_pharmacy(point_coords):
    search_api_server = "https://search-maps.yandex.ru/v1/"
    api_key = "dda3ddba-c9ea-4ead-9010-f43fbc15c6e3"

    search_params = {
        "apikey": api_key,
        "text": "аптека",
        "lang": "ru_RU",
        "ll": ",".join(point_coords),
        "type": "biz",
        "results": 1
    }

    response = requests.get(search_api_server, params=search_params)
    if not response:
        raise Exception("Ошибка выполнения запроса к API поиска")

    json_response = response.json()
    if not json_response["features"]:
        raise Exception("Аптеки не найдены")

    org = json_response["features"][0]
    org_coords = org["geometry"]["coordinates"]
    props = org["properties"]["CompanyMetaData"]

    return {
        "coordinates": [str(org_coords[0]), str(org_coords[1])],
        "name": props.get("name", "Название не указано"),
        "address": props.get("address", "Адрес не указан"),
        "hours": props.get("Hours", {}).get("text", "Время работы не указано")
    }


def show_map(points):
    map_params = {
        "l": "map",
        "pt": "~".join([
            f"{points['start']['coordinates'][0]},{points['start']['coordinates'][1]},pm2rdl",
            f"{points['pharmacy']['coordinates'][0]},{points['pharmacy']['coordinates'][1]},pm2gnl"
        ]),
        "apikey": "f3a0fe3a-b07e-4840-a1da-06f18b2ddf13"
    }

    bounds = get_bounds([
        points['start']['coordinates'],
        points['pharmacy']['coordinates']
    ])
    map_params.update(bounds)

    map_api_server = "https://static-maps.yandex.ru/1.x/"
    response = requests.get(map_api_server, params=map_params)

    Image.open(BytesIO(response.content)).show()


def print_snippet(data):
    print("\n" + "=" * 50)
    print(f"Исходный адрес: {data['start']['address']}")
    print("\nНайдена аптека:")
    print(f"Название: {data['pharmacy']['name']}")
    print(f"Адрес: {data['pharmacy']['address']}")
    print(f"Время работы: {data['pharmacy']['hours']}")
    print(f"Расстояние: {data['distance']} метров")
    print("=" * 50 + "\n")


def main():
    if len(sys.argv) < 2:
        print("Использование: python pharmacy_search.py <адрес>")
        return

    try:
        address = " ".join(sys.argv[1:])

        start_point = geocode_address(address)

        pharmacy = find_nearest_pharmacy(start_point["coordinates"])

        distance = calculate_distance(
            start_point["coordinates"],
            pharmacy["coordinates"]
        )

        points_data = {
            "start": {
                "coordinates": start_point["coordinates"],
                "address": start_point["address"]
            },
            "pharmacy": {
                "coordinates": pharmacy["coordinates"],
                "name": pharmacy["name"],
                "address": pharmacy["address"],
                "hours": pharmacy["hours"]
            },
            "distance": distance
        }

        print_snippet(points_data)

        show_map(points_data)

    except Exception as e:
        print(f"Ошибка: {e}")


if __name__ == "__main__":
    main()
