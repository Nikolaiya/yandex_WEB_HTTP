import sys
from io import BytesIO
import requests
from PIL import Image
from map_scale import get_map_scale


def main():
    toponym_to_find = " ".join(sys.argv[1:])

    geocoder_api_server = "http://geocode-maps.yandex.ru/1.x/"
    geocoder_params = {
        "apikey": "8013b162-6b42-4997-9691-77b7074026e0",
        "geocode": toponym_to_find,
        "format": "json"
    }

    response = requests.get(geocoder_api_server, params=geocoder_params)
    if not response:
        print("Ошибка выполнения запроса к геокодеру")
        return

    json_response = response.json()
    toponym = json_response["response"]["GeoObjectCollection"]["featureMember"][0]["GeoObject"]
    toponym_coordinates = toponym["Point"]["pos"]
    toponym_longitude, toponym_lattitude = toponym_coordinates.split(" ")

    spn = get_map_scale(toponym)

    map_params = {
        "ll": ",".join([toponym_longitude, toponym_lattitude]),
        "spn": spn,
        "l": "map",
        "pt": f"{toponym_longitude},{toponym_lattitude},pm2rdl",
        "apikey": "f3a0fe3a-b07e-4840-a1da-06f18b2ddf13"
    }

    map_api_server = "https://static-maps.yandex.ru/1.x/"
    response = requests.get(map_api_server, params=map_params)

    Image.open(BytesIO(response.content)).show()


if __name__ == "__main__":
    main()
