def get_map_scale(toponym):
    envelope = toponym["boundedBy"]["Envelope"]
    left, bottom = envelope["lowerCorner"].split(" ")
    right, top = envelope["upperCorner"].split(" ")

    width = abs(float(right) - float(left))
    height = abs(float(top) - float(bottom))

    return f"{width},{height}"
